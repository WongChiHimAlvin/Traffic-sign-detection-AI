"""
Train YOLO on German GTSDB。
預設資料：trainuse/GTSDB_Train_and_Test/olddata.yaml。
Outputs under ./runs; copies best weights to ./weights/best_german.pt
並匯出 ./weights/best_german.onnx（給 ONNX Runtime / 部署用）。

建議「盡力準」：加 --best（較久、較吃 VRAM）。
預設較吃資源：imgsz=1280、batch=16、cache=ram（主記憶體快取）；GPU OOM 請降 --batch/--imgsz，系統 RAM 不夠請 --cache off 或 disk。
匯出 ONNX 與訓練 imgsz 相同。
"""
from __future__ import annotations

import argparse
import os
import shutil
import sys
from pathlib import Path

import yaml
from ultralytics import YOLO

# RTX 4070 laptop: prefer small/medium weights；若本機已有 yolo*.pt 會自動沿用。
PROJECT = Path(__file__).resolve().parent
DEFAULT_DATA_YAML = PROJECT / "trainuse" / "GTSDB_Train_and_Test" / "olddata.yaml"
PY_ROOT = PROJECT.parent
WEIGHTS_DIR = PROJECT / "weights"
RUN_NAME = "gtsdb_german"
IMGSZ = 1280
DEFAULT_BATCH = 16
DEFAULT_WORKERS = 0 if sys.platform == "win32" else 4


def resolve_pretrained(*, prefer_quality: bool = False) -> str:

    order = (
        ("yolo11m.pt", "yolo11s.pt", "yolo11l.pt", "yolo11n.pt")
        if prefer_quality
        else ("yolo11s.pt", "yolo11n.pt", "yolo11m.pt", "yolo11l.pt")
    )
    for folder in (PROJECT, PY_ROOT / "HongKong", PY_ROOT):
        if not folder.is_dir():
            continue
        for name in order:
            p = folder / name
            if p.is_file():
                return str(p)
    return order[0] if prefer_quality else "yolo11s.pt"


def pick_device() -> int | str:
    import torch

    return 0 if torch.cuda.is_available() else "cpu"


def parse_device_arg(value: str) -> int | str:
    """將 CLI --device 轉成 Ultralytics / torch 可接受的型別。"""
    s = value.strip().lower()
    if s == "cpu":
        return "cpu"
    if s.startswith("cuda"):
        return value.strip()  
    if s.isdigit():
        return int(s)
    raise argparse.ArgumentTypeError(f"無效的 --device: {value!r}（請用 cpu、0、1、cuda:0 等）")


def device_requests_cuda(device: int | str) -> bool:
    """是否為「要用 NVIDIA CUDA」的裝置（非 cpu / mps）。"""
    if device == "cpu" or device is None:
        return False
    if isinstance(device, int):
        return device >= 0
    s = str(device).strip().lower()
    if s == "cpu":
        return False
    return s.startswith("cuda") or s.isdigit()


def print_torch_device_info() -> None:
    import torch

    print(f"Python: {sys.executable}")
    print(f"PyTorch: {torch.__version__}  cuda built: {torch.version.cuda or 'none'}")
    print(f"torch.cuda.is_available(): {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"GPU 0: {torch.cuda.get_device_name(0)}")
    else:
        vis = os.environ.get("CUDA_VISIBLE_DEVICES", "")
        if vis.strip() == "-1" or vis.strip().lower() == "none":
            print("提示: CUDA_VISIBLE_DEVICES 關閉了 GPU，請取消該環境變數後重試。")
        elif "+cpu" in torch.__version__.lower() or "cpu" in torch.__version__.split("+")[-1].lower():
            print("提示: 目前為 CPU 版 PyTorch；請安裝含 CUDA 的 wheel，例如:")
            print("  pip install torch torchvision --index-url https://download.pytorch.org/whl/cu124")
        else:
            print("提示: 驅動或執行檔未對上 CUDA；請更新 NVIDIA 驅動，並確認用同一個 venv 的 python。")


def _resolve_data_root(data_yaml: Path, path_field: str) -> Path:
    p = Path(path_field.strip())
    if not p.is_absolute():
        p = (data_yaml.parent / p).resolve()
    else:
        p = p.resolve()
    return p


def main() -> None:
    parser = argparse.ArgumentParser(description="Train German GTSDB YOLO + export ONNX")
    parser.add_argument(
        "--data",
        type=Path,
        default=DEFAULT_DATA_YAML,
        help="資料 yaml（預設 trainuse/GTSDB_Train_and_Test/olddata.yaml）",
    )
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument(
        "--imgsz",
        type=int,
        default=IMGSZ,
        help=f"訓練與 ONNX 匯出邊長（預設 {IMGSZ}）；VRAM 不足可改 960／640",
    )
    parser.add_argument(
        "--batch",
        type=int,
        default=DEFAULT_BATCH,
        help=f"訓練 batch（預設 {DEFAULT_BATCH}）；CUDA OOM 請改小",
    )
    parser.add_argument(
        "--cache",
        type=str,
        choices=("off", "ram", "disk"),
        default="ram",
        help="資料快取：ram 吃主記憶體、常加速讀圖；disk 折衷；off 最省 RAM（預設 ram，榨效能）",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=DEFAULT_WORKERS,
        help="DataLoader 程序數；Windows 建議 0 避免 WinError 1455",
    )
    parser.add_argument(
        "--best",
        action="store_true",
        help="最佳品質預設：epoch=150、patience=50、預訓練優先 yolo11m（VRAM 不足請改小 --batch，例如 4）",
    )
    parser.add_argument(
        "--device",
        type=str,
        default=None,
        metavar="DEV",
        help="訓練裝置：cpu、0、cuda:0 等；省略則自動（有 CUDA 用 GPU 0）",
    )
    args = parser.parse_args()

    data_yaml = args.data if args.data.is_absolute() else (PROJECT / args.data).resolve()
    if not data_yaml.is_file():
        raise FileNotFoundError(f"Missing {data_yaml}")

    with open(data_yaml, encoding="utf-8") as f:
        data_cfg = yaml.safe_load(f)
    path_raw = data_cfg.get("path")
    if path_raw is None or str(path_raw).strip() in ("", "."):
        data_root = data_yaml.parent.resolve()
    else:
        data_root = _resolve_data_root(data_yaml, str(path_raw))
    if not data_root.is_dir():
        raise FileNotFoundError(
            f"資料集根目錄不存在: {data_root}\n"
            "請先執行: python prepare_gtsdb_yolo.py --src \"含 gt.txt 與街景圖的資料夾\""
        )

    os.chdir(PROJECT)

    print_torch_device_info()
    if args.device is not None:
        device = parse_device_arg(args.device)
    else:
        device = pick_device()

    import torch

    if device_requests_cuda(device) and not torch.cuda.is_available():
        german_py = PROJECT / ".venv" / "Scripts" / "python.exe"
        msg = (
            "\n無法使用 CUDA：您指定了 GPU（--device），但此 Python 的 PyTorch 看不到 GPU。\n"
            f"  目前直譯器: {sys.executable}\n"
        )
        if german_py.is_file() and Path(sys.executable).resolve() != german_py.resolve():
            msg += (
                "  專案內另有虛擬環境，請改用:\n"
                f'    "{german_py}" train.py ...\n'
                "  或在 German 資料夾執行: .\\.venv\\Scripts\\activate\n"
            )
        msg += (
            "  若堅持用目前環境，請安裝 CUDA 版 PyTorch，例如:\n"
            "    pip install torch torchvision --index-url https://download.pytorch.org/whl/cu124\n"
            "  若暫時只要 CPU 訓練，請改: --device cpu\n"
        )
        print(msg)
        raise SystemExit(1)

    print(f"訓練使用 device={device!r}")
    if device == "cpu":
        print("Warning: 目前為 CPU 訓練（較慢）。若本機有 NVIDIA GPU，請看上方診斷與 pip 的 torch 是否為 cu124/cu121 版。")

    prefer_q = bool(args.best)
    pre = resolve_pretrained(prefer_quality=prefer_q)
    epochs = 150 if args.best else args.epochs
    patience = 50 if args.best else 100
    print(f"Pretrained: {pre}")
    print(f"Data yaml: {data_yaml}")
    if args.best:
        print(f"模式: --best（epochs={epochs}, patience={patience}）")
    imgsz = max(32, int(args.imgsz))
    cache_val: bool | str = {"off": False, "ram": "ram", "disk": "disk"}[args.cache]
    print(f"imgsz={imgsz}（訓練與匯出 ONNX 相同）  batch={args.batch}  cache={args.cache!r}")
    model = YOLO(pre)
    model.train(
        data=str(data_yaml),
        epochs=epochs,
        imgsz=imgsz,
        batch=args.batch,
        device=device,
        workers=args.workers,
        patience=patience,
        cache=cache_val,
        project=str(PROJECT / "runs" / "detect"),
        name=RUN_NAME,
        exist_ok=True,
    )

    best = PROJECT / "runs" / "detect" / RUN_NAME / "weights" / "best.pt"
    WEIGHTS_DIR.mkdir(parents=True, exist_ok=True)
    if best.is_file():
        dst = WEIGHTS_DIR / "best_german.pt"
        shutil.copy2(best, dst)
        print(f"Saved copy: {dst}")
        _export_onnx(dst, WEIGHTS_DIR / "best_german.onnx", imgsz=imgsz)
    else:
        print(f"Expected best weights not found: {best}")


def _export_onnx(src_pt: Path, dst_onnx: Path, *, imgsz: int) -> None:
    """由 .pt 匯出 ONNX，寫入 weights/best_german.onnx。"""
    try:
        m = YOLO(str(src_pt))
        exported = m.export(format="onnx", imgsz=max(32, int(imgsz)), simplify=True)
        exp = Path(exported)
        if not exp.is_file():
            print(f"ONNX export returned non-file: {exported}")
            return
        if exp.resolve() != dst_onnx.resolve():
            shutil.copy2(exp, dst_onnx)
        print(f"Saved ONNX: {dst_onnx}")
    except Exception as e:
        print(f"ONNX export skipped or failed: {e}")
        print("可稍後執行: python export_german_onnx.py")


if __name__ == "__main__":
    main()
