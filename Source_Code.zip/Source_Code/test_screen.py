"""
用「整個螢幕畫面」即時測試交通標誌 YOLO（預設：德國 GTSDB 模型）。

會週期性擷取螢幕 → 推論 → 在視窗顯示結果（方便對著瀏覽器裡的照片、影片測）。

若用「全螢幕」擷取，預覽視窗也會被拍進去，可能造成迴影；可改用第二螢幕放預覽，
或使用 --bbox 只框住網頁／圖片區域。

  python test_screen.py
  python test_screen.py --image German/trainuse/.../valid/images/某張.jpg   # 先確認模型在本機有框
  python test_screen.py --infer-scale 2 --conf 0.05                        # 全螢幕標誌很小時：推論前放大
  python test_screen.py --small-sign                                      # 一鍵小標（960、放大 2.25×、conf 0.06）
  python test_screen.py --small-sign-strong                               # 更吃效能但更利遠景小標
  python test_screen.py --max-quality                                     # 盡力拉高推論品質（較慢）
  python test_screen.py --tiling --conf 0.08                              # 切塊推論：全螢幕小標較易出框（較慢）
  # 預覽視窗預設等比縮至最大寬 2048px（不影響推論）；完整解析度預覽：--max-view-width 0

本腳本只載入 .onnx（不會使用 .pt）。
預設權重：與本腳本同目錄的 best_german.onnx
自訂：  --weights 某路徑.onnx

依賴：Pillow（ImageGrab），專案 venv 通常已有。

操作：
  q / ESC  結束
  s        將目前「含偵測框」的畫面存成 screen_snapshot.jpg（py 根目錄）

可選參數 --bbox 只擷取某個矩形區域（加快 FPS、專注一塊畫面）。

為何常「整片螢幕都沒框」：
  Roboflow/GTSDB 多為「標誌裁切圖、佔畫面很大」；全螢幕或遠景裡標誌很小，分數容易低於門檻。
  請試：--conf 0.05～0.1、--infer-scale 放大、--bbox 只框住放大的路標圖、或 --debug 看低門檻下的最高分。
  若 ONNX 為固定輸入邊長（例如 640 或 1280），腳本會自動把 --imgsz 對齊該邊長；手動傳的 imgsz 與 ONNX 不符會被覆寫。
  若「框大致對但標籤永遠錯同一套」：預設使用 ONNX 內嵌類別名稱；若與訓練 yaml 不一致可傳 --data-yaml 覆寫顯示名稱。
  若仍錯，多半是「模型預測的 class id」與你以為的語意不符（標註或編號問題），
  可跑 German/diagnose_gtsdb_class_ids.py 檢查；或慎用 --display-remap 自訂「顯示用」對照（不治本）。
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import ImageGrab
from ultralytics import YOLO

ROOT = Path(__file__).resolve().parent

# 與 test_screen.py 同資料夾（例如 IA_AI/best_german.onnx）
GERMAN_ONNX = (ROOT / "best_german.onnx").resolve()
SNAPSHOT_PATH = ROOT / "screen_snapshot.jpg"
# 預覽視窗預設上限（等比縮小，不放大）；推論仍用完整擷取／infer-scale 後的圖
DEFAULT_MAX_VIEW_WIDTH = 2048
DEFAULT_MAX_VIEW_HEIGHT = 0  # 0=只限寬度；可設 720 等以同時限制高度


def resize_preview_view(
    view: np.ndarray, max_w: int, max_h: int
) -> np.ndarray:
    """等比縮放預覽，不超過 max_w／max_h（0=不限制該邊）；不會放大超過原圖。"""
    if view.size == 0:
        return view
    h, w = view.shape[:2]
    if max_w <= 0 and max_h <= 0:
        return view
    sw = (max_w / w) if max_w > 0 else float("inf")
    sh = (max_h / h) if max_h > 0 else float("inf")
    s = min(1.0, sw, sh)
    if s >= 1.0 - 1e-9:
        return view
    nw = max(1, int(round(w * s)))
    nh = max(1, int(round(h * s)))
    return cv2.resize(view, (nw, nh), interpolation=cv2.INTER_AREA)


def resolve_onnx(weights_arg: Path | None) -> tuple[Path, str]:
    """只解析 .onnx 路徑；回傳 (路徑, 提示)。"""
    if weights_arg is not None:
        p = weights_arg.expanduser().resolve()
        if p.suffix.lower() != ".onnx":
            raise ValueError(
                f"test_screen 僅支援 .onnx，收到：{p}\n"
                "請先執行 German/export_german_onnx.py 或訓練結束後的 ONNX 匯出。"
            )
        return p, ""
    return GERMAN_ONNX, ""


def weights_tag(weights_path: Path) -> str:
    rp = weights_path.resolve()
    try:
        if rp == GERMAN_ONNX.resolve():
            return "GTSDB-ONNX"
    except OSError:
        pass
    pos = weights_path.as_posix().replace("\\", "/")
    if "German" in pos:
        return "GTSDB-ONNX"
    return weights_path.stem


def pick_device(force_cpu: bool) -> int | str:
    if force_cpu or not torch.cuda.is_available():
        return "cpu"
    return 0


def grab_screen_bgr(bbox: tuple[int, int, int, int] | None) -> np.ndarray:
    """PIL 回傳 RGB，轉成 OpenCV 用的 BGR uint8。"""
    img = ImageGrab.grab(bbox=bbox)
    rgb = np.array(img)
    if rgb.ndim == 2:
        rgb = cv2.cvtColor(rgb, cv2.COLOR_GRAY2RGB)
    return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)


def onnx_fixed_input_spatial_size(onnx_path: Path) -> int | None:
    """若 ONNX 第一個輸入的 H、W 為固定正整數，回傳較小邊（通常即 letterbox 邊長）；動態則 None。"""
    try:
        import onnxruntime as ort

        so = ort.SessionOptions()
        so.log_severity_level = 4
        sess = ort.InferenceSession(
            str(onnx_path),
            sess_options=so,
            providers=["CPUExecutionProvider"],
        )
        shp = sess.get_inputs()[0].shape
    except Exception:
        return None
    if len(shp) < 4:
        return None
    h, w = shp[2], shp[3]
    if not isinstance(h, int) or not isinstance(w, int) or h <= 0 or w <= 0:
        return None
    return min(h, w)


def resolve_data_yaml_for_names(args: argparse.Namespace) -> Path | None:
    """僅在指定 --data-yaml 時覆寫顯示名稱；否則用 ONNX 內嵌 names。"""
    if getattr(args, "no_yaml_names", False):
        return None
    if getattr(args, "data_yaml", None) is not None:
        return args.data_yaml.expanduser().resolve()
    return None


def apply_class_names_from_data_yaml(
    model: YOLO, yaml_path: Path, *, force_cpu: bool, imgsz: int
) -> None:
    """ONNX 內嵌的 names 有時與實際訓練用 data.yaml 不一致，導致「同一類一直顯示錯名字」。

    先做一次暖身推論建立 predictor，再把 AutoBackend.names 換成 yaml 的 names。
    """
    from ultralytics.nn.autobackend import check_class_names
    from ultralytics.utils import YAML

    data = YAML.load(str(yaml_path))
    raw = data.get("names")
    if raw is None:
        raise ValueError(f"{yaml_path} 沒有 names 欄位")
    names_map = check_class_names(raw)
    isz = max(32, int(imgsz))
    warm = np.zeros((isz, isz, 3), dtype=np.uint8)
    kw: dict = {"verbose": False, "save": False, "imgsz": isz}
    if force_cpu:
        kw["device"] = "cpu"
    model.predict(warm, **kw)
    model.predictor.model.names = names_map


def ensure_predictor_warmed_up(model: YOLO, *, force_cpu: bool, imgsz: int) -> None:
    if model.predictor is not None:
        return
    isz = max(32, int(imgsz))
    warm = np.zeros((isz, isz, 3), dtype=np.uint8)
    kw: dict = {"verbose": False, "save": False, "imgsz": isz}
    if force_cpu:
        kw["device"] = "cpu"
    model.predict(warm, **kw)


def iter_tiles(
    h: int, w: int, tile_h: int, tile_w: int, overlap: float
) -> list[tuple[int, int, int, int]]:
    """回傳不重複的 (x0,y0,x1,y1) 視窗，用於 image[y0:y1, x0:x1]。"""
    th = min(int(tile_h), h)
    tw = min(int(tile_w), w)
    ov = max(0.0, min(0.95, float(overlap)))
    if th <= 0 or tw <= 0:
        return [(0, 0, w, h)]
    if th == h and tw == w:
        return [(0, 0, w, h)]
    step_y = max(1, int(th * (1 - ov)))
    step_x = max(1, int(tw * (1 - ov)))
    y_stops: list[int] = []
    y = 0
    while y + th < h:
        y_stops.append(y)
        y += step_y
    y_stops.append(h - th)
    x_stops: list[int] = []
    x = 0
    while x + tw < w:
        x_stops.append(x)
        x += step_x
    x_stops.append(w - tw)
    y_stops = sorted(set(y_stops))
    x_stops = sorted(set(x_stops))
    out: list[tuple[int, int, int, int]] = []
    for y0 in y_stops:
        for x0 in x_stops:
            out.append((x0, y0, x0 + tw, y0 + th))
    return out


def _nms_merge_tiles(
    xyxy: np.ndarray,
    scores: np.ndarray,
    cls_ids: np.ndarray,
    *,
    iou_th: float,
    max_det: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """同類別內做 NMS，再依分數取前 max_det。"""
    import torch
    import torchvision

    if xyxy.size == 0:
        return xyxy, scores, cls_ids
    keep_all: list[int] = []
    for c in np.unique(cls_ids):
        m = cls_ids == c
        idxs = np.flatnonzero(m)
        if idxs.size == 0:
            continue
        b = torch.from_numpy(xyxy[m].astype(np.float32))
        s = torch.from_numpy(scores[m].astype(np.float32))
        k = torchvision.ops.nms(b, s, float(iou_th))
        keep_all.extend(idxs[k.cpu().numpy()])
    keep_all = np.array(keep_all, dtype=np.int64)
    order = scores[keep_all].argsort()[::-1][: max(1, int(max_det))]
    sel = keep_all[order]
    return xyxy[sel], scores[sel], cls_ids[sel]


def predict_tiled(
    model: YOLO,
    image_bgr: np.ndarray,
    pred_kw: dict,
    *,
    tile_h: int,
    tile_w: int,
    overlap: float,
    merge_iou: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, int]:
    """切塊 predict，座標對齊整張 image_bgr。回傳 (xyxy, conf, cls, n_tiles)。"""
    H, W = image_bgr.shape[:2]
    tiles = iter_tiles(H, W, tile_h, tile_w, overlap)
    base_kw = {k: v for k, v in pred_kw.items() if k != "source"}
    boxes_parts: list[np.ndarray] = []
    scores_parts: list[np.ndarray] = []
    cls_parts: list[np.ndarray] = []

    for x0, y0, x1, y1 in tiles:
        crop = image_bgr[y0:y1, x0:x1]
        if crop.size == 0 or crop.shape[0] < 4 or crop.shape[1] < 4:
            continue
        kw = {**base_kw, "source": crop}
        r = model.predict(**kw)[0]
        if r.boxes is None or len(r.boxes) == 0:
            continue
        xy = r.boxes.xyxy.cpu().numpy()
        xy[:, [0, 2]] += x0
        xy[:, [1, 3]] += y0
        boxes_parts.append(xy)
        scores_parts.append(r.boxes.conf.cpu().numpy())
        cls_parts.append(r.boxes.cls.cpu().numpy().astype(np.int64))

    if not boxes_parts:
        z = np.zeros((0, 4), dtype=np.float32)
        return z, np.array([]), np.array([]), len(tiles)

    xyxy = np.concatenate(boxes_parts, axis=0)
    scores = np.concatenate(scores_parts, axis=0)
    clss = np.concatenate(cls_parts, axis=0)
    md = int(base_kw.get("max_det", 300))
    xyxy, scores, clss = _nms_merge_tiles(
        xyxy, scores, clss, iou_th=merge_iou, max_det=md
    )
    return xyxy, scores, clss, len(tiles)


def draw_boxes_bgr(
    img: np.ndarray,
    xyxy: np.ndarray,
    scores: np.ndarray,
    classes: np.ndarray,
    names: dict | list,
    *,
    line_width: int = 2,
    font_scale: float = 0.5,
) -> np.ndarray:
    out = img.copy()
    for i in range(len(xyxy)):
        x1, y1, x2, y2 = (int(round(v)) for v in xyxy[i])
        x1 = max(0, min(x1, img.shape[1] - 1))
        x2 = max(0, min(x2, img.shape[1] - 1))
        y1 = max(0, min(y1, img.shape[0] - 1))
        y2 = max(0, min(y2, img.shape[0] - 1))
        if x2 <= x1 or y2 <= y1:
            continue
        cid = int(classes[i])
        cf = float(scores[i])
        if isinstance(names, dict):
            lab = names.get(cid, str(cid))
        else:
            lab = names[cid] if cid < len(names) else str(cid)
        label = f"{lab} {cf:.2f}"
        color = (
            int(37 * (cid % 7) % 255),
            int(17 * (cid % 5) % 255),
            int(29 * (cid % 3) % 255),
        )
        cv2.rectangle(out, (x1, y1), (x2, y2), color, line_width)
        cv2.putText(
            out,
            label[:72],
            (x1, max(0, y1 - 4)),
            cv2.FONT_HERSHEY_SIMPLEX,
            font_scale,
            color,
            1,
            cv2.LINE_AA,
        )
    return out


def apply_display_class_remap(model: YOLO, remap_path: Path) -> None:
    """僅改「畫面上的類別文字」：模型輸出 k 時，改顯示目前 names 裡第 v 個名稱。

    JSON 格式：{"6": 14, "14": 6} 表示輸出 6 顯示原本 14 的名稱。無法修正分錯類的模型，只適用於
    你已確認的 id↔語意對照錯誤（例如 Roboflow 編號與 GTSDB 順序混用）。
    """
    raw = json.loads(remap_path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("display-remap JSON 須為物件")
    remap = {int(k): int(v) for k, v in raw.items()}
    base = dict(model.predictor.model.names)
    nc = len(base)
    for k, v in remap.items():
        if not (0 <= k < nc and 0 <= v < nc):
            raise ValueError(f"display-remap 鍵值須在 0..{nc - 1} 內: {k} -> {v}")
    new_names = {k: base[remap.get(k, k)] for k in range(nc)}
    model.predictor.model.names = new_names


def main() -> None:
    parser = argparse.ArgumentParser(
        description="螢幕即時測試（僅 ONNX；預設同目錄 best_german.onnx）"
    )
    parser.add_argument(
        "--weights",
        type=Path,
        default=None,
        help="自訂 .onnx 路徑；未指定時用同目錄 best_german.onnx",
    )
    parser.add_argument(
        "--conf",
        type=float,
        default=argparse.SUPPRESS,
        help="信心門檻（全螢幕小標建議 0.05～0.15；一般預設 0.1；--small-sign* 另有預設）",
    )
    parser.add_argument(
        "--imgsz",
        type=int,
        default=argparse.SUPPRESS,
        help="推論解析度；一般預設 640；小標可 960／1280 或直接用 --small-sign",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="每幀額外用很低門檻掃描，在畫面上顯示「最高分／個數」（判斷是否門檻太高）",
    )
    parser.add_argument("--cpu", action="store_true", help="強制使用 CPU")
    parser.add_argument(
        "--interval",
        type=float,
        default=0.0,
        help="每次擷取間隔秒數，>0 可略降 CPU/GPU 佔用（預設 0=盡快）",
    )
    parser.add_argument(
        "--bbox",
        type=int,
        nargs=4,
        metavar=("LEFT", "TOP", "RIGHT", "BOTTOM"),
        default=None,
        help="只擷取矩形區域（像素，螢幕座標），例如 --bbox 100 100 900 700",
    )
    parser.add_argument(
        "--max-width",
        type=int,
        default=0,
        help="若 >0，將擷取圖等比縮到最大寬度再送進模型（較快，可能略降準度）",
    )
    parser.add_argument(
        "--infer-scale",
        type=float,
        dest="infer_scale",
        default=argparse.SUPPRESS,
        help=(
            "推論前將擷取圖長寬乘上此倍率（>1 可拉大小標；顯示時會縮回螢幕解析度）。"
            "若設了 --max-width，會先 max-width 再乘 infer-scale。"
        ),
    )
    sign_grp = parser.add_mutually_exclusive_group()
    sign_grp.add_argument(
        "--small-sign",
        action="store_true",
        help="小標一鍵：預設 infer-scale=2.25、imgsz=960、conf=0.06（仍可用 --conf 等單獨覆寫）",
    )
    sign_grp.add_argument(
        "--small-sign-strong",
        action="store_true",
        help="小標加強：infer-scale=2.5、imgsz=1280、conf=0.05（較慢、較吃 VRAM）",
    )
    parser.add_argument(
        "--max-quality",
        action="store_true",
        help=(
            "盡力拉高準度（仍受模型／資料限制）：至少 imgsz≥1280、infer-scale≥2.5，"
            "並用較嚴 NMS（iou=0.55、max_det=150，除非你再傳 --iou / --max-det）"
        ),
    )
    parser.add_argument(
        "--iou",
        type=float,
        default=argparse.SUPPRESS,
        help="NMS 的 IoU 門檻（預設 0.7；略降如 0.55 有時可減少重疊假框）",
    )
    parser.add_argument(
        "--max-det",
        type=int,
        dest="max_det",
        default=argparse.SUPPRESS,
        help="每幀最多保留幾個框（預設 300；降低可減少雜訊框）",
    )
    parser.add_argument(
        "--max-view-width",
        type=int,
        default=DEFAULT_MAX_VIEW_WIDTH,
        help=(
            f"預覽最大寬度（像素）；等比縮小、不放大。預設 {DEFAULT_MAX_VIEW_WIDTH}，"
            "每次執行視窗大小較一致。設 0=不限制寬度（與擷取同寬，可能很大）"
        ),
    )
    parser.add_argument(
        "--max-view-height",
        type=int,
        default=DEFAULT_MAX_VIEW_HEIGHT,
        help=(
            "預覽最大高度（像素）；0=只依 --max-view-width 等比縮放。"
            "可設 720 等，讓超高螢幕預覽也不會過高"
        ),
    )
    parser.add_argument(
        "--tiling",
        action="store_true",
        help="滑動視窗切塊推論（每塊 imgsz×imgsz，重疊合併+NMS），利全螢幕遠景小標；明顯較慢",
    )
    parser.add_argument(
        "--tile-overlap",
        type=float,
        default=0.2,
        help="切塊重疊比例 0～0.9（預設 0.2）；越大越不易漏標、越慢",
    )
    parser.add_argument(
        "--tile-merge-iou",
        type=float,
        default=None,
        help="跨塊合併 NMS 的 IoU（預設與 --iou 相同）",
    )
    parser.add_argument(
        "--image",
        type=Path,
        default=None,
        help="改讀圖檔／影片路徑，不擷螢幕（用來確認 ONNX 與 venv 是否正常；操作鍵相同）",
    )
    parser.add_argument(
        "--data-yaml",
        type=Path,
        default=None,
        help="可選：用此 data.yaml 的 names 覆寫畫面上的類別文字（預設使用 ONNX 內嵌 names）",
    )
    parser.add_argument(
        "--no-yaml-names",
        action="store_true",
        help="不要從 yaml 覆寫名稱，完全使用 ONNX 內嵌的 names",
    )
    parser.add_argument(
        "--display-remap",
        type=Path,
        default=None,
        help=(
            "JSON：{\"模型輸出的class id\": 顯示時改用的名稱索引}。只改文字、不改推理。"
            "若不知對照請勿亂填；可先跑 German/diagnose_gtsdb_class_ids.py"
        ),
    )
    args = parser.parse_args()

    if args.small_sign_strong:
        args.conf = getattr(args, "conf", 0.05)
        args.imgsz = getattr(args, "imgsz", 1280)
        args.infer_scale = getattr(args, "infer_scale", 2.5)
    elif args.small_sign:
        args.conf = getattr(args, "conf", 0.06)
        args.imgsz = getattr(args, "imgsz", 960)
        args.infer_scale = getattr(args, "infer_scale", 2.25)
    else:
        args.conf = getattr(args, "conf", 0.1)
        args.imgsz = getattr(args, "imgsz", 640)
        args.infer_scale = getattr(args, "infer_scale", 1.0)

    if args.max_quality:
        args.imgsz = max(int(args.imgsz), 1280)
        args.infer_scale = max(float(args.infer_scale), 2.5)
        if not hasattr(args, "iou"):
            args.iou = 0.55
        if not hasattr(args, "max_det"):
            args.max_det = 150
    args.iou = getattr(args, "iou", 0.7)
    args.max_det = getattr(args, "max_det", 300)
    if args.iou <= 0 or args.iou > 1:
        raise ValueError("--iou 須在 (0, 1] 之間")
    if args.max_det < 1:
        raise ValueError("--max-det 須 ≥ 1")
    if args.tiling and (args.tile_overlap < 0 or args.tile_overlap >= 0.95):
        raise ValueError("--tile-overlap 請用 [0, 0.95) 內的值")

    weights_path, weight_hint = resolve_onnx(args.weights)
    if not weights_path.is_file():
        raise FileNotFoundError(
            "找不到 ONNX 模型。\n"
            f"  預設路徑：{GERMAN_ONNX}\n"
            "請將 best_german.onnx 放在與本腳本同目錄，或使用 --weights 指向你的 .onnx。"
        )

    onnx_cap = onnx_fixed_input_spatial_size(weights_path)
    if onnx_cap is not None:
        cur = int(args.imgsz)
        if cur != onnx_cap:
            why = (
                "大於 ONNX 固定邊長，已壓回"
                if cur > onnx_cap
                else "小於 ONNX 固定邊長，已對齊（否則會 RuntimeError: Expected vs Got）"
            )
            print(
                f"注意: 此 ONNX 輸入固定為 {onnx_cap}×{onnx_cap}，"
                f"已將 imgsz 由 {cur} 改為 {onnx_cap}（{why}）。"
                "遠景小標請用 --infer-scale / --bbox；若要改推理解析度請重新匯出對應尺寸的 ONNX。"
            )
            args.imgsz = onnx_cap

    tag = weights_tag(weights_path)

    bbox = None
    if args.bbox is not None:
        left, top, right, bottom = args.bbox
        if right <= left or bottom <= top:
            raise ValueError("--bbox 需滿足 LEFT<RIGHT 且 TOP<BOTTOM")
        bbox = (left, top, right, bottom)

    device = pick_device(force_cpu=args.cpu)
    dev_name = (
        f"GPU cuda:0 ({torch.cuda.get_device_name(0)})"
        if device == 0
        else "CPU"
    )
    print(f"權重 ({tag}): {weights_path}")
    if weight_hint:
        print(weight_hint)
    print("格式: ONNX（onnxruntime；若未裝 GPU provider 可能走 CPU）")
    print(f"（系統 PyTorch CUDA 狀態，供參考）: {dev_name}")
    if bbox:
        print(f"擷取區域 bbox={bbox}")
    if args.image is not None:
        ip = args.image.expanduser().resolve()
        if not ip.exists():
            raise FileNotFoundError(f"--image 不存在：{ip}")
        print(f"來源: 檔案 {ip}（非螢幕擷取）")
    if args.small_sign_strong:
        print(
            "小標模式（強）：infer-scale=2.5、目標 imgsz=1280、conf=0.05"
            "（ONNX 若固定 640 則 imgsz 已自動壓低；另傳參數可覆寫）"
        )
    elif args.small_sign:
        print(
            "小標模式：infer-scale=2.25、目標 imgsz=960、conf=0.06"
            "（ONNX 若固定 640 則 imgsz 已自動壓低；另傳參數可覆寫）"
        )
    if args.max_quality:
        print(
            f"高品質模式：infer-scale≥2.5、實際 imgsz={args.imgsz}、"
            f"NMS iou={args.iou}、max_det={args.max_det}"
        )
    if args.max_view_width > 0 or args.max_view_height > 0:
        print(
            f"預覽縮放上限: 寬≤{args.max_view_width or '∞'}px 高≤{args.max_view_height or '∞'}px "
            "（僅顯示；推論仍用完整擷取／infer-scale）"
        )
    if args.infer_scale != 1.0:
        print(f"推論放大 infer-scale={args.infer_scale}（有助遠景小標）")
    if args.tiling:
        _mio = (
            args.tile_merge_iou
            if args.tile_merge_iou is not None
            else args.iou
        )
        print(
            f"切塊推論 --tiling：每塊 {args.imgsz}×{args.imgsz}、"
            f"overlap={args.tile_overlap}、合併 NMS IoU={_mio}"
        )
    print("按 q 或 ESC 結束；按 s 截圖存檔")
    print("（推論無 loss；框上為信心 conf）")
    if "GTSDB" in tag or "German" in str(weights_path):
        print(
            "提示: 德國 ONNX 多在「裁切大標」上訓練；全螢幕若仍無框，"
            "試 --tiling、--small-sign 或 --debug，並用 --bbox 框住路標區。"
        )

    model = YOLO(str(weights_path), task="detect")

    name_yaml = resolve_data_yaml_for_names(args)
    if name_yaml is not None and name_yaml.is_file():
        try:
            apply_class_names_from_data_yaml(
                model, name_yaml, force_cpu=args.cpu, imgsz=int(args.imgsz)
            )
            print(f"類別顯示名稱已依 data.yaml 覆寫（{name_yaml.name}，共 {len(model.predictor.model.names)} 類）")
        except Exception as exc:
            print(f"警告: 無法從 yaml 覆寫類別名稱，將沿用 ONNX 內嵌: {exc}")
    elif name_yaml is not None and not name_yaml.is_file():
        print(f"警告: 找不到 data.yaml（{name_yaml}），無法覆寫類別名稱")

    if args.display_remap is not None:
        rp = args.display_remap.expanduser().resolve()
        if not rp.is_file():
            raise FileNotFoundError(f"--display-remap 不存在：{rp}")
        try:
            ensure_predictor_warmed_up(
                model, force_cpu=args.cpu, imgsz=int(args.imgsz)
            )
            apply_display_class_remap(model, rp)
            print(f"已套用顯示用 class 對照: {rp}")
        except Exception as exc:
            raise RuntimeError(f"套用 --display-remap 失敗: {exc}") from exc

    src_label = "FILE" if args.image is not None else "SCREEN"
    window = f"YOLO {tag} — {src_label} | q/ESC 離開 | s 截圖"

    cap = None
    if args.image is not None:
        p = str(args.image.expanduser().resolve())
        cap = cv2.VideoCapture(p)
        if not cap.isOpened():
            raise RuntimeError(f"無法以 OpenCV 開啟：{p}")

    prev_t = time.perf_counter()
    fps_smooth = 0.0

    try:
        while True:
            if cap is not None:
                ok, frame = cap.read()
                if not ok:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    ok, frame = cap.read()
                    if not ok:
                        break
            else:
                frame = grab_screen_bgr(bbox)

            if args.max_width > 0 and frame.shape[1] > args.max_width:
                scale = args.max_width / frame.shape[1]
                frame = cv2.resize(
                    frame,
                    (args.max_width, int(frame.shape[0] * scale)),
                    interpolation=cv2.INTER_AREA,
                )

            infer_scale = float(args.infer_scale)
            if infer_scale <= 0:
                raise ValueError("--infer-scale 必須 > 0")
            if infer_scale != 1.0:
                fh, fw = frame.shape[:2]
                frame_infer = cv2.resize(
                    frame,
                    (max(1, int(fw * infer_scale)), max(1, int(fh * infer_scale))),
                    interpolation=cv2.INTER_LINEAR,
                )
            else:
                frame_infer = frame

            pred_kw: dict = {
                "source": frame_infer,
                "conf": args.conf,
                "imgsz": args.imgsz,
                "iou": args.iou,
                "max_det": args.max_det,
                "save": False,
                "verbose": False,
            }
            if args.cpu:
                pred_kw["device"] = "cpu"

            n_tiles = 1
            if args.tiling:
                merge_iou = (
                    float(args.tile_merge_iou)
                    if args.tile_merge_iou is not None
                    else float(args.iou)
                )
                isz = int(args.imgsz)
                xyxy, scores, clss, n_tiles = predict_tiled(
                    model,
                    frame_infer,
                    pred_kw,
                    tile_h=isz,
                    tile_w=isz,
                    overlap=float(args.tile_overlap),
                    merge_iou=merge_iou,
                )
                names = model.predictor.model.names
                if len(xyxy) == 0:
                    out = frame_infer.copy()
                    n_det = 0
                else:
                    out = draw_boxes_bgr(
                        frame_infer, xyxy, scores, clss, names
                    )
                    n_det = len(xyxy)
            else:
                results = model.predict(**pred_kw)
                r0 = results[0]
                out = r0.plot(line_width=2, font_size=1)
                n_det = len(r0.boxes) if r0.boxes is not None else 0

            if infer_scale != 1.0:
                out = cv2.resize(
                    out,
                    (frame.shape[1], frame.shape[0]),
                    interpolation=cv2.INTER_AREA,
                )

            debug_line = ""
            if args.debug:
                if args.tiling:
                    if len(xyxy) > 0:
                        bi = int(np.argmax(scores))
                        c = float(scores[bi])
                        cid = int(clss[bi])
                        nm = model.predictor.model.names
                        label = (
                            nm.get(cid, str(cid))
                            if isinstance(nm, dict)
                            else (nm[cid] if cid < len(nm) else str(cid))
                        )
                        debug_line = (
                            f"tiling×{n_tiles} merged | best {c:.2f} {str(label)[:28]}"
                        )
                    else:
                        debug_line = (
                            f"tiling×{n_tiles} | merged 0 (試降 --conf 或加 infer-scale)"
                        )
                else:
                    peek_kw = {**pred_kw, "conf": 0.02}
                    pr = model.predict(**peek_kw)[0]
                    boxes = pr.boxes
                    if boxes is not None and len(boxes) > 0:
                        best_i = int(boxes.conf.argmax().item())
                        c = float(boxes.conf[best_i].item())
                        cid = int(boxes.cls[best_i].item())
                        nm = pr.names
                        label = nm.get(cid, str(cid)) if isinstance(nm, dict) else (
                            nm[cid] if cid < len(nm) else str(cid)
                        )
                        debug_line = (
                            f"debug@0.02: {len(boxes)} raw  |  best {c:.2f} {label[:28]}"
                        )
                    else:
                        debug_line = "debug@0.02: 0 raw (模型在此畫面幾乎無反應)"

            now = time.perf_counter()
            dt = now - prev_t
            prev_t = now
            if dt > 0:
                inst_fps = 1.0 / dt
                fps_smooth = inst_fps if fps_smooth == 0 else (0.9 * fps_smooth + 0.1 * inst_fps)

            bar_h = 104 if args.debug else 78
            h, w = out.shape[:2]
            overlay = out.copy()
            cv2.rectangle(overlay, (0, 0), (w, bar_h), (40, 40, 40), thickness=-1)
            out = cv2.addWeighted(overlay, 0.55, out, 0.45, 0)

            font = cv2.FONT_HERSHEY_SIMPLEX
            y = 22
            line1 = (
                f"{tag}  {src_label}  FPS ~{fps_smooth:.1f}  |  Det: {n_det}  "
                f"|  min conf = {args.conf:.2f}"
            )
            line2 = "Box labels = class + confidence (not training loss)"
            cv2.putText(out, line1, (8, y), font, 0.55, (240, 240, 240), 1, cv2.LINE_AA)
            cv2.putText(out, line2, (8, y + 26), font, 0.45, (200, 200, 200), 1, cv2.LINE_AA)
            if args.debug and debug_line:
                cv2.putText(
                    out,
                    debug_line[:95],
                    (8, y + 52),
                    font,
                    0.42,
                    (180, 220, 255),
                    1,
                    cv2.LINE_AA,
                )

            view = resize_preview_view(
                out, int(args.max_view_width), int(args.max_view_height)
            )
            cv2.imshow(window, view)
            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), ord("Q"), 27):
                break
            if key in (ord("s"), ord("S")):
                # 存檔用完整疊圖解析度（與預覽是否縮放無關）
                cv2.imwrite(str(SNAPSHOT_PATH), out)
                print(f"已儲存: {SNAPSHOT_PATH}")

            if args.interval > 0:
                time.sleep(args.interval)
    finally:
        if cap is not None:
            cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
